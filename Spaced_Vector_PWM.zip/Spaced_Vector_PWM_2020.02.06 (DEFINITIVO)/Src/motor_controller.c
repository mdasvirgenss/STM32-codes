/*
 * motor_controller.c
 *
 *  Created on: 27 de set de 2019
 *      Author: lusvi
 */

#include "motor_controller.h"
#include "constants.h"
#include <math.h>
#include <tim.h>

int measure_direction(float *n)
{
	if (*n<0)
	{
		*n = - *n;
		return CLOCKWISE;
	}
	else return COUNTER_CLOCKWISE;
}

/*Cálculo da tensão e frequência da onda modulado conforme a velocidade via controle escalar*/
int escalar_control(float n, float *v_ref, float *f)
{
	static float n_old = -1; 						  //variável auxiliar para verificar se houve alteração da rotação do motor
	if (n_old == n) return 0; 						  // é preservado os elementos dos vetores caso a rotação seja a mesma
	//caso contrário será necessário calcular a tensão e frequẽncia e atualizar os vetores conforme a rotação
	if(S==1)  return -1;
	else if (!S) *f = n*P/(120*(1-S)); 				 //caso haja fator de escorregamento
	else *f = n/N_S*F;		  								 //caso o motor seja perfeitamente síncrono
	//Cálculo da tensão de pico da onda
	if(*f <= F_LOW)  *v_ref = V_RMS*F_LOW/F; 	 		//condicional para ajuste de curva em baixas frequências (abaixo de 20 Hz)
	else  if (*f>F_LOW && *f<F)*v_ref = V_RMS* *f/F; // Vpeak = sqrt(2) * fluxo magnetico * frequência de operação
	else *v_ref = V_RMS; //caso a frequência seja acima da nominal, é limitada a tensão de linha
	//*v_ref /= sqrt(3); //conversão tensão de linha para tensão de fase (CARGA EM ESTRELA)
	n_old = n; 	//atualização da variável auxiliar
	return 1; 	// retorna "1" para indicar necessidade de update dos vetores
}



/*Funcão de rampa de aceleração*/
int accelerate_ramp(float *n, float n_final, int time_s, float *v_ref, float *f)
{
	static int i = 0; 											//variável contradora
	static float n_init; 										// rotação incial do motor
	if(!i) n_init = *n;
	uint16_t max_iterations = time_s*1000/ROUTINE_MS; 			//número máximo de iterações conforme o tempo da rampa
	if (*n  == n_final)
	{
		i = 0;													// estado reset = reinicia a variável contadora
		return 1; 												//caso a rotação já seja a desejada, não haverá rampa de aceleração
	}
	if (i < max_iterations-1) 									//caso esteja ocorrendo a rampa de aceleração
	{
		i ++; 													//incremento da variável contradora
		*n =  *n + (n_final - n_init)/(float) max_iterations; 	//incremento/decremento da rotação do motor
		escalar_control(*n,v_ref,f); 							//atualização da tensão e frequência da onda
		return 0; 												//indica que ainda não atingiu  a rotação desejada
	}
	else
	{
		*n = n_final; 											//a rotação do motor agora é a desejada
		escalar_control(*n,v_ref,f);							//atualização da tensão e frequência da onda
		i = 0;													//reset da variável contadora
		return 1; 												//indica que foi  atingida  a rotação desejada
	}
}


/*Inicialização dos vetores com as ondas moduladas*/
void SVPWM_init(int a_phase[ROWS][LENGTH_MAX], int b_phase[ROWS][LENGTH_MAX],int c_phase[ROWS][LENGTH_MAX], int *index, int *max_iterations)
{
	for(uint16_t i=0;i<LENGTH_MAX;i++)
	{
		a_phase[*index][i] = 0;
		b_phase[*index][i] = 0;
		c_phase[*index][i] = 0;
	}
	*index ^= 1;
	max_iterations[*index] = -1;
}


//Cálculo do número de iterações do novo vetor a ser atualizado
int calculate_length_array(float f)
{
	if(!f) return -1; //caso a frequência seja (praticamente) nula, não há necessidade de ficar realizando iterações para calcular um novo vetor
	else if(f<=F_MIN) return LENGTH_MAX; // número máximo de iterações para determinada frequência elétrica (setor) //talvez passar como ponteiro para alterar o valor da frequência para o mínimo
	else return  floor(F_PWM/f/6);
}
/*Rotina de interrupção para cálculo de Vref e dos ciclos de trabalho para os 3 canais*/
int SVPWM_calculate(float f, float mag_vref, int *p_a_phase, int *p_b_phase,  int *p_c_phase, int *max_iterations)
{
	*max_iterations = calculate_length_array(f); //cálculo do tamanho do novo vetor
	//caso a frequência seja nula, não haverá onda a ser modulada
	static uint16_t i=0;
	if(*max_iterations == -1)
	{
		i= 0;
		return 1; // não haverá modulação e a saída dos canais serão 0
	}
	// rotina para cálculo instantâneo das tensões durante um período
	float phase_vref = 2*PI*f*i/F_PWM; //cálculo de theta
	//cálculo de T1,T2 e T0 para o primeiro setor
	float T1 = sqrt(3)*T_PWM*mag_vref/V_DC*sinf(PI/3-phase_vref);
	float T2 = sqrt(3)*T_PWM*mag_vref/V_DC*sinf(phase_vref);
	float T0 = T_PWM -T1-T2;
	// cálculo do T_on em cada canal para o primeiro setor
	float CCR1 = T1 + T2 + T0/2;
	float CCR2 = T2 + T0/2;
	float CCR3 = T0/2;
	// conversão dos tempos a serem enviados aos registradores CCRx
	CCR1 *= ARRx/T_PWM;
	CCR2 *= ARRx/T_PWM;
	CCR3 *= ARRx/T_PWM;
	p_a_phase[i]  = (int) CCR1;
	p_b_phase[i]  = (int) CCR2;
	p_c_phase[i]  = (int) CCR3;
	i++;
	if (i==*max_iterations)
	{
		i = 0;
		return 1;
	}
	else return 0;
}

void SVPWM_write(int a_phase[], int b_phase[], int c_phase[], int max_iterations) //envio dos sinais PWM
{
	static int i = LENGTH_MAX;
	static int n = 6;
	if(max_iterations == -1)
	{
		__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1,0);
		__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2,0);
		__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_3,0);
		n = 6;
		i = LENGTH_MAX;
	}
	else
	{
		if(i<max_iterations-1) i++;
		else
		{
			i=0;
			if(n<6) n++;
			else n = 1;
		}
		switch(n)
		{
			case 1:
				__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1,a_phase[i]);
				__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2,b_phase[i]);
				__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_3,c_phase[i]);
				break;
			case 2:
				__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1,b_phase[i]);
				__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2,a_phase[i]);
				__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_3,c_phase[i]);
				break;
			case 3:
				__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1,c_phase[i]);
				__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2,a_phase[i]);
				__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_3,b_phase[i]);
				break;
			case 4:
				__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1,c_phase[i]);
				__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2,b_phase[i]);
				__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_3,a_phase[i]);
				break;
			case 5:
				__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1,b_phase[i]);
				__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2,c_phase[i]);
				__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_3,a_phase[i]);
				break;
			case 6:
				__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1,a_phase[i]);
				__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2,c_phase[i]);
				__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_3,b_phase[i]);
			break;
		}
	}
}

void SVPWM_send(int a_phase[], int b_phase[], int c_phase[], int max_iterations, int direction)
{
	if(direction == COUNTER_CLOCKWISE)  SVPWM_write(a_phase ,b_phase, c_phase, max_iterations);
	else SVPWM_write(a_phase ,c_phase, b_phase, max_iterations);
}
