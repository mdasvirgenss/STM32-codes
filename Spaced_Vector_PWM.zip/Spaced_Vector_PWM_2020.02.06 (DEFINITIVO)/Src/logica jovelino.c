/*
 * logica jovelino.c
 *
 *  Created on: 14 de jan de 2020
 *      Author: m_dasvigenss
 */

/*
f_calculo = 0;
indice_atualizado = 0;
indice_atual = indice_atualizado;
p_a_phase = &a_phase[indice_atual][0];
indice_atualizado = 1;
while
	{


if(SVPWM_update_2(f,vp,&a_phase[indice_atualizado],b_phase,c_phase,&max_iterations_new)==1)
{
	indice_atual = indice_atualizado;
	if(indice_atualizado == 1)
	{
		indice_atualizado = 0;
	}
	else
	{
		indice_atualizado =1;
	}

	p_a_phase = &a_phase[indice_atual][0];
}
*/


