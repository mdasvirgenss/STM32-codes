/*
 * motor_controller.h
 *
 *  Created on: 27 de set de 2019
 *      Author: lusvi
 */

#ifndef MOTOR_CONTROLLER_H_
#define MOTOR_CONTROLLER_H_

#include "constants.h"

int measure_direction(float *n); //
int escalar_control(float n, float *v_ref, float *f); //C�lculo da tens�o e frequ�ncia da onda conforme a rota��o em RPM
void SVPWM_init(int a_phase[ROWS][LENGTH_MAX], int b_phase[ROWS][LENGTH_MAX],int c_phase[ROWS][LENGTH_MAX], int *index, int *max_iterations);
int calculate_length_array(float f);

void SVPWM_reset(int *sin_a_phase, int *sin_b_phase, int *sin_c_phase); //inicializa��o/ reset dos vetores PWM = prenchimento com zero
int SVPWM_calculate(float f, float mag_vref, int *p_a_phase, int *p_b_phase,  int *p_c_phase, int *max_iterations);


void SVPWM_write(int sin_a_phase[], int sin_b_phase[], int sin_c_phase[], int max_iterations); //envio dos sinais PWM
void SVPWM_send(int a_phase[], int b_phase[], int c_phase[], int max_iterations, int direction);
int accelerate_ramp(float *n, float n_final, int time_s, float *v_ref, float *f); //rampa de acelera��o


#endif /* MOTOR_CONTROLLER_H_ */
