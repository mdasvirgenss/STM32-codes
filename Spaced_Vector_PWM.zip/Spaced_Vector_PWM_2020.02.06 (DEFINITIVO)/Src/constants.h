/*
 * constants.h
 *
 *  Created on: 27 de set de 2019
 *      Author: lusvi
 */

#ifndef CONSTANTS_H_
#define CONSTANTS_H_

#define PI 					3.14159265359

#define F_PWM				20000		//frequ�ncia da portadora - TIMER 1
#define T_PWM 				0.00005		//per�odo da portadora - TIMER 1
#define ARRx				599			//Valor armazenado no registrador de AutoReload

/* Dados do motor */
#define V_RMS 				49       	//Tens�o RMS
#define F  					200			//Frequ�ncia el�trica
#define P					8 			//n�mero de p�los
#define N_M 				3000		// Rota��o do motor (no rotor) em rpm
#define N_S 				3000		//120*F/P 	//rota��o sincrona (no estator) em rpm
#define S					0			//(N_S-N_M)/N_S 	//fator de escorregamento
#define V_DC 				30			//Tens�o de alimenta��o dos MOSFETs


#define ROWS 				2
#define LENGTH_MAX 			500			//Tamanho m�ximo dos vetores
#define F_LOW 				10			//abaixo desta frequ�ncia a tens�o de linha ser� constante  para ajuste de curva
//frequ�ncia m�nima na qual � poss�vel modular as ondas senoidais = 6.7 Hz
#define F_MIN  	 			6.7			//F_PWM/LENGTH_MAX/6

#define COUNTER_CLOCKWISE 	1
#define CLOCKWISE 		 	0

#define N_MIN				0
#define N_MAX				750
#define TIME_ACCEL			5
#define TIME_SLOW			10
#define ROUTINE_MS 			100  //tempo de atualização, em milisegundos, da rotação do motor
#define FINISH				1
#define NOT_FINISH			0

/*
 * N = 30 	f = 2 Hz
 * N = 75  	f = 5Hz
 * N = 150	f = 10 Hz
 * N = 300  f = 20 HZ
 * N = 500 	f = 33.333 Hz
 * N = 750	f = 50 Hz
 * N = 1050	f = 70 Hz 		-> MÁXIMO PARA 30 V
 * N = 1500	f = 100
 * N = 2650 f = 176,739 Hz 	-> MÁXIMO PARA 75 V
 * N = 3000 f = 200 		-> MÁXIMO PARA 85 V
 */
#endif /* CONSTANTS_H_ */

