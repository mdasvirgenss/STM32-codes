/**
  ******************************************************************************
  * @file    Project/STM32F4xx_StdPeriph_Template/stm32f4xx_it.c 
  * @author  MCD Application Team
  * @version V1.1.0
  * @date    18-January-2013
  * @brief   Main Interrupt Service Routines.
  *          This file provides template for all exceptions handler and 
  *          peripherals interrupt service routine.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2013 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software 
  * distributed under the License is distributed on an "AS IS" BASIS, 
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_it.h"
#include "transceiver.h"
#include "peripheral.h"

/** @addtogroup Template_Project
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/******************************************************************************/
/*            Cortex-M4 Processor Exceptions Handlers                         */
/******************************************************************************/

/**
  * @brief   This function handles NMI exception.
  * @param  None
  * @retval None
  */
void NMI_Handler(void)
{
}

/**
  * @brief  This function handles Hard Fault exception.
  * @param  None
  * @retval None
  */
void HardFault_Handler(void)
{
  /* Go to infinite loop when Hard Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Memory Manage exception.
  * @param  None
  * @retval None
  */
void MemManage_Handler(void)
{
  /* Go to infinite loop when Memory Manage exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Bus Fault exception.
  * @param  None
  * @retval None
  */
void BusFault_Handler(void)
{
  /* Go to infinite loop when Bus Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Usage Fault exception.
  * @param  None
  * @retval None
  */
void UsageFault_Handler(void)
{
  /* Go to infinite loop when Usage Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles SVCall exception.
  * @param  None
  * @retval None
  */
void SVC_Handler(void)
{
}

/**
  * @brief  This function handles Debug Monitor exception.
  * @param  None
  * @retval None
  */
void DebugMon_Handler(void)
{
}

/**
  * @brief  This function handles PendSVC exception.
  * @param  None
  * @retval None
  */
void PendSV_Handler(void)
{
}

/**
  * @brief  This function handles SysTick Handler.
  * @param  None
  * @retval None
  */
void SysTick_Handler(void)
{
/*  TimingDelay_Decrement(); */
}

/******************************************************************************/
/*                 STM32F4xx Peripherals Interrupt Handlers                   */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_stm32f40xx.s/startup_stm32f427x.s).                         */
/******************************************************************************/

/**
  * @brief  This function handles PPP interrupt request.
  * @param  None
  * @retval None
  */
/*void PPP_IRQHandler(void)
{
}*/

/**
  * @}
  */ 


/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/

void	EXTI0_IRQHandler(void)
{
	static	uint8_t	i	=	1;
	/*******   >>  STEPS FOLLOWED << *****************
	User Push Button	->	PA0
	(1)	Check the Pin, which triggered the Interrupt
	(2)	Clear the Interrupt Pending Bit (Interrupt Flag)
	**************************************************/
	if	(EXTI->PR	&&	(1<<EXTI_PR_PR0))	//	(1)	If PA0 EXT Interrupt flag is SET
	{
		EXTI->PR	&=	~(1<<EXTI_PR_PR0);	//	(2) Clear Interrupt flag in case rising edge was detected
		i	^=	1;
		GPIO_Toggle_LED3();
	}
}

void	TIM4_IRQHandler(void)
{
	static uint16_t	i	=	4095;
	static	uint8_t	dir	=	0;	// 0 = down, 1 = up
	if(TIM4->SR	&	TIM_SR_UIF)			//	(1)	If Timer4 Interrupt flag is SET
	{
		TIM4->SR	&=	~TIM_SR_UIF;	//	(2) Clear Interrupt flag in case Timer6 Interrupt flag is SET
/*
		if(!dir)
		{
			if(i)
				i--;
			else
				dir ^=	1;
		}
		else
		{
			if (i < 4095)
				i++;
			else
				dir ^=	1;
		}
		GPIO_PWM_SetCCR_LED6(i);
*/
		if(RX_Data_ADC[0] < 100)
			GPIO_PWM_SetCCR_LED6(0);
		else
			GPIO_PWM_SetCCR_LED6(RX_Data_ADC[0]);
	}
}


void	TIM7_IRQHandler(void)
{
	if(TIM7->SR	&	TIM_SR_UIF)			//	(1)	If Timer7 Interrupt flag is SET
	{
		TIM7->SR	&=	~TIM_SR_UIF;	//	(2) Clear Interrupt flag in case Timer6 Interrupt flag is SET

		GPIO_Toggle_LED5();
	}
}

void	TIM8_UP_TIM13_IRQHandler(void)
{
	if(TIM8->SR	&	TIM_SR_UIF)			//	(1)	If Timer8 Interrupt flag is SET
	{
		TIM8->SR	&=	~TIM_SR_UIF;	//	(2) Clear Interrupt flag in case Timer6 Interrupt flag is SET
		measurementUnit_routine			(1, RX_Data_ADC[0]); // Execute sensor unit protocol
	}
}

