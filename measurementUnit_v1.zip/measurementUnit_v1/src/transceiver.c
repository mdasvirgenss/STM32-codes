/*
 * transceiver.c
 *
 *  Created on: 21 de jun de 2024
 *      Author: Usu�rio
 */

#include "stm32f4xx.h"
#include "peripheral.h"

#define		STATE_IDLE				0
#define		STATE_PRESTART			1
#define		STATE_START				2
#define		STATE_SEND_MEAS_DATA	3
#define		STATE_SEND_SYNC			4
#define		STATE_PRESTOP			5
#define		STATE_STOP				6

#define		ADDRESS_MEAS_UNIT_01	0x3
#define		ADDRESS_MEAS_UNIT_02	0x4
#define		ADDRESS_MEAS_UNIT_03	0x5
#define		ADDRESS_MEAS_UNIT_04	0x6

#define		MEAS_UNIT_ADDRESS		ADDRESS_MEAS_UNIT_01	//	Sensor Unit ADDRESS


#define		TOTAL_NUMBER_OF_PULSES	10						//	Number of PWM cycles for data frame (only sensor data + synchronization)


#define		PWM_THRESHOLD			200
#define		PWM_MAX_WIDTH			4095
#define		PWM_LIMIT_LOWER			PWM_THRESHOLD
#define		PWM_LIMIT_UPPER			PWM_MAX_WIDTH-PWM_THRESHOLD



uint8_t	measurementUnit_getAddress(void)	//	Not Used
{
	return MEAS_UNIT_ADDRESS;
	//return	measurementUnit_Address;
}

uint8_t	measurementUnit_determineState2(uint8_t sendDataFlag)	//  Determine Data Frame State
{
	static uint8_t	state = STATE_IDLE;
	static uint8_t	pulseCounter = 0;
	if(!sendDataFlag)											// If is not allowed to send data frame, go to IDLE (reset) state
	{
		sendDataFlag 	= STATE_IDLE;
		pulseCounter	=	0;
		return state;
	}
	else														// If it is allowed to send data frame
	{
		if(	(state == STATE_SEND_MEAS_DATA) | (state == STATE_SEND_SYNC)	)
				pulseCounter++;
		else
			pulseCounter = 0;
		switch(state)
		{
		case(STATE_IDLE):
				state = STATE_PRESTART;
				pulseCounter	=	0;
				break;
		case(STATE_PRESTART):
				state =	STATE_SEND_MEAS_DATA;
				break;
/*
		case(STATE_START):
				state =	STATE_SEND_MEAS_DATA;
				break;
 */
		case(STATE_SEND_MEAS_DATA):
				if(pulseCounter > MEAS_UNIT_ADDRESS)
					state =	STATE_SEND_SYNC;
				break;
		case(STATE_SEND_SYNC):
				if(pulseCounter > TOTAL_NUMBER_OF_PULSES)
					state	=	STATE_PRESTART;
				break;
/*
		case(STATE_PRESTOP):
				state	=	STATE_SEND_MEAS_DATA;
				break;
		case(STATE_STOP):
				state	=	STATE_SEND_MEAS_DATA;
				break;
*/
		default:
				state	=	STATE_IDLE;
				break;
		}
	}
	return state;
}






uint8_t	measurementUnit_determineState(uint8_t sendDataFlag)
{
	static uint8_t	state = STATE_IDLE;
	static uint8_t	pulseCounter = 0;
	if(!sendDataFlag)
	{
		sendDataFlag 	= STATE_IDLE;
		pulseCounter	=	0;
		return state;
	}
	else
	{
		if(	(state == STATE_SEND_MEAS_DATA) | (state == STATE_SEND_SYNC)	)
				pulseCounter++;
		else
			pulseCounter = 0;
		switch(state)
		{
		case(STATE_IDLE):
				state = STATE_PRESTART;
				pulseCounter	=	0;
				break;
		case(STATE_PRESTART):
				state =	STATE_START;
				break;
		case(STATE_START):
				state =	STATE_SEND_MEAS_DATA;
				break;
		case(STATE_SEND_MEAS_DATA):
				if(pulseCounter > MEAS_UNIT_ADDRESS)
					state =	STATE_SEND_SYNC;
				break;
		case(STATE_SEND_SYNC):
				if(pulseCounter > TOTAL_NUMBER_OF_PULSES)
					state	=	STATE_PRESTOP;
				break;
		case(STATE_PRESTOP):
				state	=	STATE_PRESTART;
				break;
		case(STATE_STOP):
				state	=	STATE_PRESTART;
				break;
		default:
				state	=	STATE_IDLE;
				break;
		}
	}
	return state;
}

uint16_t	PWM_limiter	(uint16_t width)
{
	if(width < PWM_LIMIT_LOWER)
		return PWM_LIMIT_LOWER;
	else
	{
		if(width > PWM_LIMIT_UPPER)
			return PWM_LIMIT_UPPER;
	}
	return width;

}

void	measurementUnit_sendPWM(uint8_t state, uint16_t data)
{
	// Set data frame output accordingly data frame state
	switch(state)
	{
		case(STATE_IDLE):
			GPIO_PWM_SetCCR_BFSK(0);				//	Output Level LOW; 0 % duty cycle
			break;
		case(STATE_PRESTART):
			GPIO_PWM_SetCCR_BFSK(PWM_MAX_WIDTH);	//	Output Level HIGH; 100 % duty cycle
			break;
		case(STATE_START):
			GPIO_PWM_SetCCR_BFSK(PWM_LIMIT_UPPER);	//	Not Used
			break;
		case(STATE_SEND_MEAS_DATA):
			GPIO_PWM_SetCCR_BFSK(PWM_limiter(data)); // Duty cycle as per sensor data (limited)
			break;
		case(STATE_SEND_SYNC):
			GPIO_PWM_SetCCR_BFSK(PWM_MAX_WIDTH);	//	Output Level HIGH; 100 % duty cycle
			break;
		case(STATE_PRESTOP):
			GPIO_PWM_SetCCR_BFSK(PWM_LIMIT_UPPER);	//	Not Used
			break;
		case(STATE_STOP):
			GPIO_PWM_SetCCR_BFSK(0);				//	Not Used
			break;
		default:
			GPIO_PWM_SetCCR_BFSK(0);				//	Output Level LOW; 0 % duty cycle
			break;
	}
}

void	measurementUnit_routine(uint8_t sendDataFlag, uint16_t data)
{
	static uint16_t measurementData = 0;
	uint8_t	state = measurementUnit_determineState2(sendDataFlag);			//	Determine data frame state
	if(state == STATE_PRESTART)
		measurementData = data;												//	Sample sensor data at each data frame
	measurementUnit_sendPWM(state, measurementData);						//	Send sampled sensor data into data frame
}

