/*
 * transceiver.h
 *
 *  Created on: 21 de jun de 2024
 *      Author: Usu�rio
 */

#ifndef TRANSCEIVER_H_
#define TRANSCEIVER_H_




uint8_t		measurementUnit_getAddress		(void);
uint8_t		measurementUnit_determineState	(uint8_t sendDataFlag);
uint8_t		measurementUnit_determineState2	(uint8_t sendDataFlag);
uint16_t	PWM_limiter						(uint16_t width);
void		measurementUnit_sendPWM			(uint8_t state, uint16_t data);
void		measurementUnit_routine			(uint8_t sendDataFlag, uint16_t data);


#endif /* TRANSCEIVER_H_ */
