/*
 * peripheral.c
 *
 *  Created on: 21 de jun de 2024
 *      Author: Usu�rio
 */


#include "stm32f4xx.h"

#define		SYSCLK_MHz				168				//	Main Clock at 168 MHz
#define		AHB_MHz					SYSCLK_MHz/1
#define		APB1_MHz				SYSCLK_MHz/4
#define		APB2_MHz				SYSCLK_MHz/2

#define		AF3						0x3
#define		GPIO_AFRH_AFRH8_Pos		0X0
#define		GPIO_AFRL_AFRL1_Pos		0X4

#define		AF2						0x2
#define		GPIO_AFRH_AFRH15_Pos	0x1C

#define	V_25						0.76
#define	AVG_SLOPE					0.0025
#define	V_DD						3.3
#define	ADC_MAX_VALUE				4095
#define	BITS_TO_VOLTS				V_DD/ADC_MAX_VALUE



void	GPIO_Config_LED3	(void)
{
	/*******   >>  STEPS FOLLOWED << *****************
	LED3	(Orange)	->	PD13
	(1)	Enable GPIO Clock
	(2)	Configure Pin as OUTPUT
	(3)	Configure OUTPUT MODE
	**************************************************/
	RCC->AHB1ENR 		|=	RCC_AHB1ENR_GPIODEN;		//	(1)	Enable GPIOD Clock
	GPIOD->MODER		|=	GPIO_MODER_MODER13_0; 		//	(2)	Configure Pin as OUTPUT
	//GPIOD->OTYPER		=	0;							//	(3)	output type : push-pull (reset value)
	//GPIOD->OSPEEDR	=	0;  						//	(3)	output speed : low speed (reset value)
}

void	GPIO_Config_LED4	(void)
{
	/*******   >>  STEPS FOLLOWED << *****************
	LED4 (Green)	->	PD12
	(1)	Enable GPIO Clock
	(2)	Configure Pin as OUTPUT
	(3)	Configure OUTPUT MODE
	**************************************************/
	RCC->AHB1ENR 		|=	RCC_AHB1ENR_GPIODEN;		//	(1)	Enable GPIOD Clock
	GPIOD->MODER		|=	GPIO_MODER_MODER12_0; 		//	(2)	Configure Pin as OUTPUT
	//GPIOD->OTYPER		=	0;							//	(3)	output type : push-pull (reset value)
	//GPIOD->OSPEEDR	=	0;  						//	(3)	output speed : low speed (reset value)
}

void	GPIO_Config_LED5	(void)
{
	/*******   >>  STEPS FOLLOWED << *****************
	LED5 (Red)	->	PD14
	(1)	Enable GPIO Clock
	(2)	Configure Pin as OUTPUT
	(3)	Configure OUTPUT MODE
	**************************************************/
	RCC->AHB1ENR 		|=	RCC_AHB1ENR_GPIODEN;		//	(1)	Enable GPIOD Clock
	GPIOD->MODER		|=	GPIO_MODER_MODER14_0; 		//	(2)	Configure Pin as OUTPUT
	//GPIOD->OTYPER		=	0;							//	(3)	output type : push-pull (reset value)
	GPIOD->OSPEEDR		|=	GPIO_OSPEEDER_OSPEEDR14_1;  //	(3)	output speed : high speed
}


void	GPIO_Config_LED6	(void)
{
	/*******   >>  STEPS FOLLOWED << *****************
	Alternative Function: TIM4_CHN4	->	PD15
	(1)	Enable GPIO Clock
	(2)	Configure Pin as Alternative Function
	(3)	Select specific Alternative Function
	(4)	Configure OUTPUT MODE
	**************************************************/
	RCC->AHB1ENR	|=	RCC_AHB1ENR_GPIODEN;				//	(1)	Enable GPIOC Clock
	GPIOD->MODER	|=	GPIO_MODER_MODER15_1;				//	(2)	Configure Pin as Alternative Function
	GPIOD->AFR[1]	|=	(AF2	<<	GPIO_AFRH_AFRH15_Pos);	//	(3)	Select on PD15: TIM4_CHN4 = AF2, 4'b0010 =  AF2, AFR[1] = AFRH
	//GPIOC->OTYPER	=	0;									//	(4.1) Output type : push-pull (reset value)
	GPIOD->OSPEEDR	|=	GPIO_OSPEEDER_OSPEEDR15_1;			//	(4.2) Output speed : high speed
}

void	GPIO_Config_PB	(void)
{	/*******   >>  STEPS FOLLOWED << *****************
	User Push Button	->	PA0
	(1)	Enable GPIO Clock
	(2)	Configure Pin as INPUT
	(3)	Configure the Pull-Up / Pull-down internal resistor according to HW
	 * **************************************************/
	RCC->AHB1ENR 		|=	RCC_AHB1ENR_GPIOAEN;		//	(1)	Enable GPIOA Clock
	//GPIOA->MODER		&=	~(GPIO_MODER_MODER0); 		//	(2)	Configure Pin as INPUT (reset value)
	//GPIOA->PUPDR		&=	~(GPIO_PUPDR_PUPDR0);		//	(3)	Neither pull-up or pull-down resistor enable (reset value)
}


void	GPIO_Config_PWM_OUTPUT_CHN3	(void)
{
	/*******   >>  STEPS FOLLOWED << *****************
	Alternative Function: TIM8_CHN3	->	PC8
	(1)	Enable GPIO Clock
	(2)	Configure Pin as Alternative Function
	(3)	Select specific Alternative Function
	(4)	Configure OUTPUT MODE
	**************************************************/
	RCC->AHB1ENR	|=	RCC_AHB1ENR_GPIOCEN;				//	(1)	Enable GPIOC Clock
	GPIOC->MODER	|=	GPIO_MODER_MODER8_1;				//	(2)	Configure Pin as Alternative Function
	GPIOC->AFR[1]	|=	(AF3	<<	GPIO_AFRH_AFRH8_Pos);	//	(3)	Select on PC8: TIM8_CHN3 = AF3, 4'b0011 =  AF3, AFR[0] = AFRL
	//GPIOC->OTYPER	=	0;								//	(4.1) Output type : push-pull (reset value)
	GPIOC->OSPEEDR	|=	GPIO_OSPEEDER_OSPEEDR8_1;		//	(4.2) Output speed : high speed
}

void	GPIO_Config_PWM_OUTPUT_CHN3_N	(void)
{
	/*******   >>  STEPS FOLLOWED << *****************
	Alternative Function: TIM8_CHN3_N	->	PB1
	(1)	Enable GPIO Clock
	(2)	Configure Pin as Alternative Function
	(3)	Select specific Alternative Function
	(4)	Configure OUTPUT MODE
	**************************************************/
	RCC->AHB1ENR	|=	RCC_AHB1ENR_GPIOBEN;			//	(1)	Enable GPIOB Clock
	GPIOB->MODER	|=	GPIO_MODER_MODER1_1;			//	(2)	Configure Pin as Alternative Function
	GPIOB->AFR[0]	|=	AF3	<<	GPIO_AFRL_AFRL1_Pos;	//	(3)	Select on PB1: TIM8_CHN3 = AF3, 4'b0011 =  AF3, AFR[1] = AFRH
	//GPIOB->OTYPER	=	0;								//	(4.1) Output type : push-pull (reset value)
	GPIOB->OSPEEDR	|=	GPIO_OSPEEDER_OSPEEDR1_1;		//	(4.2) Output speed : high speed
}


void	GPIO_Config_ADC_Potentiometer		(void)
{
	/*******   >>  STEPS FOLLOWED << *****************
	ADC input(ADC1_IN2)	->	PA2
	(1)	Enable GPIO Clock
	(2)	Configure Pin as Analog Mode
	(3)	Configure the Pull-Up / Pull-down internal resistor according to HW
		 * **************************************************/
	RCC->AHB1ENR 		|=	RCC_AHB1ENR_GPIOAEN;		//	(1)	Enable GPIOA Clock
	GPIOA->MODER		|=	(GPIO_MODER_MODER2); 		//	(2)	Configure Pin as Analog Mode
	//GPIOA->PUPDR		&=	~(GPIO_PUPDR_PUPDR0);		//	(3)	Neither pull-up or pull-down resistor enable (reset value)
}

void	GPIO_Config_ADC_ExternalTempSensor	(void)
{
	/*******   >>  STEPS FOLLOWED << *****************
	ADC input(ADC1_IN3)	->	PA3
	(1)	Enable GPIO Clock
	(2)	Configure Pin as Analog Mode
	(3)	Configure the Pull-Up / Pull-down internal resistor according to HW
		 * **************************************************/
	RCC->AHB1ENR 		|=	RCC_AHB1ENR_GPIOAEN;		//	(1)	Enable GPIOA Clock
	GPIOA->MODER		|=	(GPIO_MODER_MODER3); 		//	(2)	Configure Pin as Analog Mode
	//GPIOA->PUPDR		&=	~(GPIO_PUPDR_PUPDR0);		//	(3)	Neither pull-up or pull-down resistor enable (reset value)
}


void	GPIO_Config	(void)
{
	GPIO_Config_LED3();						//	LED4 (Green)	->	PD12
	GPIO_Config_LED4();						//	LED3 (Orange)	->	PD13
	GPIO_Config_LED5();						//	LED5 (Red)		->	PD14
	GPIO_Config_LED6();						//	LED6 (Blue)		->	PD15
	GPIO_Config_PB();						//	User PB			->	PA0
	GPIO_Config_PWM_OUTPUT_CHN3();			//	PWM_P			->	TIM8_CHN3	:	PC8
	GPIO_Config_PWM_OUTPUT_CHN3_N();		//	PWM_N			->	TIM8_CHN3_N	: 	PB1
	GPIO_Config_ADC_Potentiometer();		//	ADC				-> 	ADC_IN2		:	PA2
	GPIO_Config_ADC_ExternalTempSensor();	//	ADC				-> 	ADC_IN3		:	PA3
}

void	Timer_Config_TIM4	(void)
{
	/*******   >>  STEPS FOLLOWED << *****************
	Timer 8	-> Advanced timer (used to generate complementary PWM Outputs)
	(1)	Enable Timer Clock
	(2)	Set the Per-scaler and Auto-Reload
	(3) Configure PWM:
	Set Edge-aligned mode
	Set Direction (Up-counter)
	Set PWM Mode
	Enable per-load register
	Set Capture/Compare 1 output polarity
	Enable Channel Outputs (Main and Complementary)
	Set Dead-time (reset state)
	PWM Output = ON
	Enable Main Output
	(4)	Enable the  Update Interrupt	(Timer Level)
	(5)	Set the NVIC Interrupt Priority
	(6)	Enable the NVIC Interrupt
	(7)	Enable the Timer
	(8)	Force Update Generation
	**************************************************/

	RCC->APB1ENR 		|=	RCC_APB1ENR_TIM4EN;		//	(1)		Enable Timer8 Clock
	//Timer Frequency 	= TIMER_CLOCK / ( (Per-scaler+1) * (Auto-Reload+1) )
	TIM4->PSC			=	(APB1_MHz*1)	-1;		//	(2.1)	Timer clock set to 1 MHz (i.e.  1 us)
	TIM4->ARR			=	4096			-1;		//	(2.2)	Timer event each	+- 5 ms (= PWM frequency +- 200 Hz)
													//	(3) Configure PWM

	//TIM4->CR1			&=	~TIM_CR1_CMS;								//	(3.1)	Edge-aligned mode (reset state)
	//TIM4->CR1			&=	~TIM_CR1_DIR;								//	(3.2)	Direction: Counter used as up-counter (reset state)
	//OC4 ->	refers to Channel 4;
	TIM4->CCMR2			|= 	(TIM_CCMR2_OC4M_2	|	TIM_CCMR2_OC4M_1);	//	(3.3)	Select PWM mode 1 on OC4 (OC4M = 110)
	TIM4->CCMR2			|=	TIM_CCMR2_OC4PE;							//	(3.4)	Enable per-load register on OC4
	//TIM8->CCER			&=	~(TIM_CCER_CC4P);						//	(3.5)	Output  OC4 Output Polarity = active high (reset state)
	TIM4->CCER			|=	TIM_CCER_CC4E		;						//	(3.6)	Enable OC4 Output
	//TIM4->BDTR			&=	~TIM_BDTR_DTG;							//	(3.8)	No Dead-time (reset state)
	TIM4->CCR4			=	0;											//	(3.9)	PWM Output = ON for 0*5 ms
	TIM4->BDTR			|=	TIM_BDTR_MOE;								//	(3.10)	Enable Main Output

	TIM4->DIER			|=	TIM_DIER_UIE;			//	(4)		Enable the  Update interrupt (Timer Level)
	NVIC_SetPriority(TIM4_IRQn,4);					//	(5) 	Lower the number, Higher Priority
	NVIC_EnableIRQ(TIM4_IRQn);						//	(6)		Timer7 Interrupt Enable at NVIC Level
	TIM4->CR1			|=	TIM_CR1_CEN;			//	(7)		Enable the Timer counter
	TIM4->EGR			|=	TIM_EGR_UG;				//	(8)		Reinitialize the counter and generates an update of the registers
}

void	Timer_Config_TIM7	(void)
{
	/*******   >>  STEPS FOLLOWED << *****************
	Timer 7	-> BASIC timer
	(1)	Enable Timer Clock
	(2)	Set the Per-scaler and Auto-Reload
	(3)	Enable the  Update Interrupt	(Timer Level)
	(4)	Set the NVIC Interrupt Priority
	(5)	Enable the NVIC Interrupt
	(6)	Enable the Timer
	**************************************************/
	RCC->APB1ENR 		|=	RCC_APB1ENR_TIM7EN;		//	(1)		Enable Timer7 Clock
	//Timer Frequency 	= TIMER_CLOCK / ( (Per-scaler+1) * (Auto-Reload+1) )
	TIM7->PSC			=	(APB1_MHz*1000)	-1;		//	(2.1)	Timer clock set to 1 KHz (i.e. 1ms)
	TIM7->ARR			=	2000			-1;		//	(2.2)	Timer event each	2 s
	TIM7->DIER			|=	TIM_DIER_UIE;			//	(3)		Enable the  Update interrupt (Timer Level)
	NVIC_SetPriority(TIM7_IRQn,2);					//	(4) 	Lower the number, Higher Priority
	NVIC_EnableIRQ(TIM7_IRQn);						//	(5)		Timer7 Interrupt Enable at NVIC Level
	TIM7->CR1			|=	TIM_CR1_CEN;			//	(6)		Enable the Timer counter
}

void	Timer_Config_TIM8	(void)
{
	/*******   >>  STEPS FOLLOWED << *****************
	Timer 8	-> Advanced timer (used to generate complementary PWM Outputs)
	(1)	Enable Timer Clock
	(2)	Set the Per-scaler and Auto-Reload
	(3) Configure PWM:
	Set Edge-aligned mode
	Set Direction (Up-counter)
	Set PWM Mode
	Enable per-load register
	Set Capture/Compare 1 output polarity
	Enable Channel Outputs (Main and Complementary)
	Set Dead-time (reset state)
	PWM Output = ON
	Enable Main Output
	(4)	Enable the  Update Interrupt	(Timer Level)
	(5)	Set the NVIC Interrupt Priority
	(6)	Enable the NVIC Interrupt
	(7)	Enable the Timer
	(8)	Force Update Generation
	**************************************************/

	RCC->APB2ENR 		|=	RCC_APB2ENR_TIM8EN;		//	(1)		Enable Timer8 Clock
	//Timer Frequency 	= TIMER_CLOCK / ( (Per-scaler+1) * (Auto-Reload+1) )
	TIM8->PSC			=	(4)	-1;					//	(2.1)	Timer clock set to 21 MHz (i.e. +- 47 ns)
	TIM8->ARR			=	4096			-1;		//	(2.2)	Timer event each	+- 195.04 us (= PWM frequency +- 5 kHz)
	//TIM8->PSC			=	(1)	-1;					//	(2.1)	Timer clock set to 84 MHz (i.e. +- 11 ns)
	//TIM8->ARR			=	4096			-1;		//	(2.2)	Timer event each	+- 48.76 us (= PWM frequency +- 20 kHz)
	//	(3) Configure PWM
	//TIM8->CR1			&=	~TIM_CR1_CMS;								//	(3.1)	Edge-aligned mode (reset state)
	//TIM8->CR1			|=	TIM_CR1_CMS_0;								//	(3.1)	Center-aligned mode
	//TIM8->CR1			&=	~TIM_CR1_DIR;								//	(3.2)	Direction: Counter used as up-counter (reset state)
	//OC3 ->	refers to Channel 3;
	TIM8->CCMR2			|= 	(TIM_CCMR2_OC3M_2	|	TIM_CCMR2_OC3M_1);	//	(3.3)	Select PWM mode 1 on OC3 (OC3M = 110)
	TIM8->CCMR2			|=	TIM_CCMR2_OC3PE;							//	(3.4)	Enable per-load register on OC3
	//TIM8->CCER			&=	~(TIM_CCER_CC3P);						//	(3.5)	Output  OC3 Output Polarity = active high (reset state)
	//TIM8->CCER			&=	~(TIM_CCER_CC3NP);						//	(3.6)	Output  OC3 Complementary Output Polarity = active high (reset state)
	TIM8->CCER			|=	TIM_CCER_CC3E		|	TIM_CCER_CC3NE;		//	(3.7)	Enable OC3 Output and OC3 Complementary Output
	//TIM8->BDTR			&=	~TIM_BDTR_DTG;							//	(3.8)	No Dead-time (reset state)
	TIM8->CCR3			=	2000;										//	(3.9)	PWM Output = ON for (2000-1)*47 ns
	TIM8->BDTR			|=	TIM_BDTR_MOE;								//	(3.10)	Enable Main Output

	TIM8->DIER			|=	TIM_DIER_UIE;			//	(4)		Enable the  Update interrupt (Timer Level)
	NVIC_SetPriority(TIM8_UP_TIM13_IRQn,1);			//	(5) 	Lower the number, Higher Priority
	NVIC_EnableIRQ(TIM8_UP_TIM13_IRQn);				//	(6)		Timer7 Interrupt Enable at NVIC Level
	TIM8->CR1			|=	TIM_CR1_CEN;			//	(7)		Enable the Timer counter
	TIM8->EGR			|=	TIM_EGR_UG;				//	(8)		Reinitialize the counter and generates an update of the registers
}

void	Timer_Config	(void)
{
	Timer_Config_TIM4();
	Timer_Config_TIM7();
	Timer_Config_TIM8();
}

void	Interrupt_Config_PB	(void)
{
	/*******   >>  STEPS FOLLOWED << *****************
	User Push Button	->	PA0
	(1)	Enable the SYSCNFG bit in RCC register
	(2)	Configure the EXTI configuration Register in the SYSCNFG
	(3)	Unmask  EXTI Interrupt request from line using Interrupt Mask Register (IMR)
	(4)	Configure the Rising Edge Trigger
	(5)	Configure the Falling Edge Trigger
	(6)	Set the Interrupt Priority
	(7)	Enable the Interrupt
	**************************************************/

	RCC->APB2ENR	|=	RCC_APB2ENR_SYSCFGEN; 						//	(1)	Enable  SYSCNFG
	//SYSCFG->EXTICR[0]	&=	(uint16_t)	~SYSCFG_EXTICR1_EXTI0_PA;	//	(2) Select Port A for pin 0 extended interrupt by writing 0000 in EXTI0 (reset value)
	EXTI->IMR	|=	EXTI_IMR_MR0;									//	(3)	Interrupt Mask on line 0
	EXTI->RTSR	|=	EXTI_RTSR_TR0; 									//	(4)	Rising trigger event configuration bit of line 0
	//EXTI->FTSR	&=	~(EXTI_FTSR_TR0); 							// 	(5) NONE Falling trigger event configuration bit of line 0 (reset value)
	NVIC_SetPriority(EXTI0_IRQn,3);									//	(6) Lower the number, Higher Priority
	NVIC_EnableIRQ(EXTI0_IRQn);										//	(7)	EXTI0 Interrupt Enable
}


void	Interrupt_Config	(void)
{
	Interrupt_Config_PB();
}

void	GPIO_TurnOn_LED3		(void)
{
	GPIOD->ODR	|=	GPIO_ODR_ODR_13; //Turn ON LED Orange
}

void	GPIO_TurnOn_LED4		(void)
{
	GPIOD->ODR	|=	GPIO_ODR_ODR_12; //Turn ON LED Green
}

void	GPIO_TurnOn_LED5		(void)
{
	GPIOD->ODR	|=	GPIO_ODR_ODR_14; //Turn ON LED Red
}

void	GPIO_TurnOff_LED3		(void)
{
	GPIOD->ODR	&=	~GPIO_ODR_ODR_13; //Turn OFF LED Orange
}

void	GPIO_TurnOff_LED4		(void)
{
	GPIOD->ODR	&=	~GPIO_ODR_ODR_12; //Turn OFF LED Green
}

void	GPIO_TurnOff_LED5		(void)
{
	GPIOD->ODR	&=	~GPIO_ODR_ODR_14; //Turn OFF LED Red
}

void	GPIO_Toggle_LED3	(void)
{
	GPIOD->ODR	^=	GPIO_ODR_ODR_13; //Toggle LED Orange
}

void	GPIO_Toggle_LED4	(void)
{
	GPIOD->ODR	^=	GPIO_ODR_ODR_12; //Toggle LED Green
}

void	GPIO_Toggle_LED5	(void)
{
	GPIOD->ODR	^=	GPIO_ODR_ODR_14; //Toggle LED Red
}

void	GPIO_PWM_SetCCR_LED6	(uint16_t	CCR)
{
	TIM4->CCR4			=	CCR;
}



void	GPIO_PWM_SetCCR_BFSK	(uint16_t	CCR)
{
	TIM8->CCR3			=	CCR;
}


void	ADC1_Init(void)
{
	/*******   >>  STEPS FOLLOWED << *****************
	Initialize ADC1 Channel(s)
	(1)	Enable ADC clock
	(2)	Set the ADC Per-scaler
	(3)	Set the Scan Mode and Resolution (number of bits per channel)
	(4)	Set the Continuous Conversion, EOC (End-Of-Conversion) and Data Alignment
	(5)	Set the Sampling Time for the channel
	(6)	Set the Regular channel Number of Conversion (sequence length)

	**************************************************/
	RCC->APB2ENR	|=	RCC_APB2ENR_ADC1EN; 						//	(1)	Enable  ADC1 clock
	ADC->CCR		|=	ADC_CCR_ADCPRE_1;							//	(2) Per-scaler = 6; ADC_CLK =  RCC_APB2ENR_ADC1_CLK/6
	//APB2_MHz	=			SYSCLK_MHz/2	= ADC_CLK = SYSCLK_MHz/12

	ADC1->CR1		|=	ADC_CR1_SCAN;								// (3.1) Scan Mode + 12 bit resolution
	//ADC1->CR1		&=	~ADC_CR1_RES;								// (3.2) 12 bit resolution (reset value)

	ADC1->CR2		|=	ADC_CR2_CONT | ADC_CR2_EOCS;				//(4.1) Continuous Conversion + EOC (End-Of-Conversion)
	//ADC1->CR2		&=	~ADC_CR2_ALIGN ;							//(4.2) RIGHT Data Alignment (reset value)

	ADC1->SMPR1		|=	ADC_SMPR1_SMP16_2 | ADC_SMPR1_SMP16_1;		//(5.1) Sample time of 144 cycles on Channel 16
	//ADC1->SMPR2		&=	~ (ADC_SMPR2_SMP2 | ADC_SMPR2_SMP3);	//(5.2) Sample time of 3  cycles on Channels 2 and 3 (reset state)


	//ADC1->SQR1	|=	(2<<20);
	ADC1->SQR1		|=	ADC_SQR1_L_1; 								//(6) 3 Conversion(s)


	/************************************/


	/*******   >>  STEPS FOLLOWED << *****************
	Set DMA Mode
	(1)	Enable DMA mode
	(2)	Enable Continuous Requests
	(3)	Set Channel Sequence
	**************************************************/
	ADC1->CR2	|=	ADC_CR2_DMA;									//(1)	Enable DMA mode
	ADC1->CR2	|=	ADC_CR2_DDS;									//(2)  	DMA requests are issued as long as data are converted and DMA=1

	ADC1->SQR3	|=	ADC_SQR3_SQ1_1;									//(3.1)	ADC_IN2		-> 1st in regular sequence
	ADC1->SQR3	|=	ADC_SQR3_SQ2_1 | ADC_SQR3_SQ2_0;				//(3.2)	ADC_IN3		-> 2nd in regular sequence
	ADC1->SQR3	|=	ADC_SQR3_SQ3_4;									//(3.3)	ADC_IN16	-> 3rd in regular sequence
}




void	ADC1_Enable(void)
{
	/*******   >>  STEPS FOLLOWED << *****************
	Enable ADC1
	(1)	Enable ADC
	(2)	Wait for ADC to stabilize (approx 10 us)
	**************************************************/
	ADC1->CR2	|=	ADC_CR2_ADON; 									//(1.1)	ADC Converter ON
	ADC->CCR	|=	ADC_CCR_TSVREFE;								//(1.2)	Enable Temperature sensor and V_REFINT channel
	// to minimize the delay, the ADON and TSVREFE bits should be set at the same time.
	uint32_t	delay	=	SYSCLK_MHz*10;
	while	(delay--); 												//(2) approx 10 us delay
}

void	ADC1_Start(void)
{
	/*******   >>  STEPS FOLLOWED << *****************
	Start ADC1 Conversion
	(1) Clear the Status register
	(2)	Start the Conversion
	**************************************************/

	ADC1->SR 	= 0;												//(1) 	Clear the Status register
	ADC1->CR2	|=	ADC_CR2_SWSTART;								//(2)	Start Conversion of regular channels
}


void	DMA2_Init			(void)
{
	/*******   >>  STEPS FOLLOWED << *****************
	Initialize DMA2: on Stream 0, Channel 0 -> ADC1
	(1)	Enable DMA Clock
	(2)	Set the Data Direction
	(3) Enable Circular mode
	(4) Enable Memory Address Increment mode
	(5) Set the size for data (Peripheral and Memory)
	(6) Select channel for the stream
	**************************************************/

	RCC->AHB1ENR	|= RCC_AHB1ENR_DMA2EN;							//(1)Enable DMA2 Clock
	//DMA2_Stream0->CR	&=	~DMA_SxCR_DIR; 							//(2) Direction: Peripheral-to-memory (reset state)
	DMA2_Stream0->CR	|=	DMA_SxCR_CIRC;							//(3)Circular Mode selected
	DMA2_Stream0->CR	|=	DMA_SxCR_MINC;							//(4)Memory address pointer is incremented after each data transfer (increment is done according to MSIZE)
	DMA2_Stream0->CR	|= 	DMA_SxCR_PSIZE_0 | DMA_SxCR_MSIZE_0;	//(5)Half-word size for both Peripheral and Memory
	//DMA2_Stream0->CR	&=	~DMA_SxCR_CHSEL;						//(6)Channel 0 selected on Stream 0: ADC1 (reset state)
}

void	DMA2_Config(uint32_t	srcAdd,	uint32_t	destAdd,	uint8_t	size)
{
	/*******   >>  STEPS FOLLOWED << *****************
	Set DMA2
	(1)	Set the size of the transfer
	(2)	Source address is Peripheral address
	(3) Destination address is Memory address
	(4) Enable the DMA
	**************************************************/
	DMA2_Stream0->NDTR	=	size;		//(1) NDTR : Number of data items to transfer register
	DMA2_Stream0->PAR	=	srcAdd; 	//(2) PAR : peripheral address register
	DMA2_Stream0->M0AR	=	destAdd;	//(3) M0AR : memory 0 address  register

	DMA2_Stream0->CR	|=	DMA_SxCR_EN; //(4) Enable the DMA
}

float	get_internalTempInCelsius	(float data)
{
	return	(float) (	(	(	BITS_TO_VOLTS * data		- V_25	)	/	(float)AVG_SLOPE	) + 25	);
}

