/*
 * peripheral.h
 *
 *  Created on: 21 de jun de 2024
 *      Author: Usu�rio
 */

#ifndef PERIPHERAL_H_
#define PERIPHERAL_H_


#define		ADC_NUMBER_OF_CHANNELS			3

uint16_t	RX_Data_ADC[ADC_NUMBER_OF_CHANNELS];		//Array that receives ADC data from DMA

void	GPIO_Config_LED3					(void);
void	GPIO_Config_LED4					(void);
void	GPIO_Config_LED5					(void);
void	GPIO_Config_LED6					(void);
void	GPIO_Config_PB						(void);
void	GPIO_Config_PWM_OUTPUT_CHN3			(void);
void	GPIO_Config_PWM_OUTPUT_CHN3_N		(void);
void	GPIO_Config_ADC_Potentiometer		(void);
void	GPIO_Config_ADC_ExternalTempSensor	(void);
void	GPIO_Config							(void);


void	Timer_Config_TIM4					(void);
void	Timer_Config_TIM7					(void);
void	Timer_Config_TIM8					(void);
void	Timer_Config						(void);

void	Interrupt_Config_PB					(void);
void	Interrupt_Config					(void);



void	GPIO_TurnOn_LED3					(void);
void	GPIO_TurnOn_LED4					(void);
void	GPIO_TurnOn_LED5					(void);

void	GPIO_TurnOff_LED3					(void);
void	GPIO_TurnOff_LED4					(void);
void	GPIO_TurnOff_LED5					(void);

void	GPIO_Toggle_LED3					(void);
void	GPIO_Toggle_LED4					(void);
void	GPIO_Toggle_LED5					(void);

void	GPIO_PWM_SetCCR_LED6				(uint16_t	CCR);
void	GPIO_PWM_SetCCR_BFSK				(uint16_t	CCR);



void	ADC1_Init							(void);
void	ADC1_Start							(void);
void	ADC1_Enable							(void);

void	DMA2_Init							(void);
void	DMA2_Config							(uint32_t	srcAdd,	uint32_t	destAdd,	uint8_t	size);


float	get_internalTempInCelsius			(float data);

#endif /* PERIPHERAL_H_ */
